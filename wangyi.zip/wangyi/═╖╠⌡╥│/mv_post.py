from appium import webdriver
from time import sleep
from appium.webdriver.common.touch_action import  import TouchAction

desires_caps = {}
desires_caps['platformName'] = 'Android'
desires_caps['platformVersion'] = '7'
desires_caps['deviceName'] = 'FA6930305423'
desires_caps['appPackage'] = 'com.netease.newsreader.activity'
desires_caps['appActivity'] = 'com.netease.nr.phone.main.MainActivity'
desires_caps['noReset'] = True

# 启动APP
driver = webdriver.Remote('http://localhost:4723/wd/hub',desires_caps)

#等待时间
sleep(5)

#点击底部栏首页
driver.find_element_by_id("com.netease.newsreader.activity:id/a2k").click()
sleep(2)

#定义元素是否存在
def is_element_exist(self, element):
    source = self.driver.page_source
    print(source)
    if element in source:
        return True
    else:
        return False

#判断视频播放按钮是否存在
ele="com.netease.newsreader.activity:id/h1"
if self.is_element_exist("ele"):
    mv_button = driver.find_element_by_id("ele")
    mv_button.click()
else:
    TouchAction(driver).press(502,1631).move_to(504,485).relesse().perform()
    mv_button.click()

#返回首页
driver.find_element_by_id("com.netease.newsreader.activity:id/at9").click()

