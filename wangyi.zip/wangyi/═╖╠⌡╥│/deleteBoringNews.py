from appium import webdriver
from time import sleep

desires_caps = {}
desires_caps['platformName'] = 'Android'
desires_caps['platformVersion'] = '7'
desires_caps['deviceName'] = 'FA6930305423'
desires_caps['appPackage'] = 'com.netease.newsreader.activity'
desires_caps['appActivity'] = 'com.netease.nr.phone.main.MainActivity'
desires_caps['noReset'] = True

# 启动APP
driver = webdriver.Remote('http://localhost:4723/wd/hub',desires_caps)

#等待时间
sleep(5)

#点击底部栏首页
driver.find_element_by_id("com.netease.newsreader.activity:id/a2k").click()
sleep(2)

#点击删除按钮
driver.find_element_by_id("com.netease.newsreader.activity:id/jn").click()
#选择一个删除的理由
driver.find_element_by_id("com.netease.newsreader.activity:id/ag8").click()
