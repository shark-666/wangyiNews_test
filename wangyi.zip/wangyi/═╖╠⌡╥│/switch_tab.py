from appium import webdriver
from time import sleep

desires_caps = {}
desires_caps['platformName'] = 'Android'
desires_caps['platformVersion'] = '7'
desires_caps['deviceName'] = 'FA6930305423'
desires_caps['appPackage'] = 'com.netease.newsreader.activity'
desires_caps['appActivity'] = 'com.netease.nr.phone.main.MainActivity'
desires_caps['noReset'] = True

# 启动APP
driver = webdriver.Remote('http://localhost:4723/wd/hub',desires_caps)

#等待时间
sleep(5)

#点击底部栏首页
driver.find_element_by_id("com.netease.newsreader.activity:id/a2k").click()
sleep(2)

#切换顶部tab栏
driver.find_element_by_xpath('//android.widget.TextView[contains(@text, "抗疫")]').click()
sleep(1)
driver.find_element_by_xpath('//android.widget.TextView[contains(@text, "视频")]').click()
sleep(1)
driver.find_element_by_xpath('//android.widget.TextView[contains(@text, "娱乐")]').click()
sleep(1)
driver.find_element_by_xpath('//android.widget.TextView[contains(@text, "关注")]').click()
sleep(1)
driver.find_element_by_xpath('//android.widget.TextView[contains(@text, "头条")]').click()
sleep(3)
