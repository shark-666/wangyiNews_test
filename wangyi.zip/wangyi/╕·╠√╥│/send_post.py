from appium import webdriver
from time import sleep
from appium.webdriver.common.touch_action import  import TouchAction

desires_caps = {}
desires_caps['platformName'] = 'Android'
desires_caps['platformVersion'] = '7'
desires_caps['deviceName'] = 'FA6930305423'
desires_caps['appPackage'] = 'com.netease.newsreader.activity'
desires_caps['appActivity'] = 'com.netease.nr.phone.main.MainActivity'
desires_caps['noReset'] = True
desired_caps['unicodeKeyboard']='True'
desired_caps['resetKeyboard']='True'

# 启动APP
driver = webdriver.Remote('http://localhost:4723/wd/hub',desires_caps)

#等待时间
sleep(5)

#点击底部栏首页
driver.find_element_by_id("com.netease.newsreader.activity:id/a2k").click()
sleep(2)

#点击普通帖
driver.tap([455,741],500)
#点击 写跟帖 文本框
edit = driver.find_element_by_id("com.netease.newsreader.activity:id/ar_")
edit.send_keys("good job")
sleep(2)
#清空文本
edit.clear()
sleep(1)
#输入 好好学习，好好工作
edit.send_keys("好好学习，好好工作")
edit.clear()
#输入中文、英文、数字、特殊字符的文本
edit.send_keys("我是梁艺，I'am liangyi,666,~!@#$%^&*()???")
sleep(2)
driver.find_element_by_id("com.netease.newsreader.activity:id/arh").click()


#返回首页
driver.find_element_by_id("com.netease.newsreader.activity:id/rw").click()

