from appium import webdriver
from time import sleep
from appium.webdriver.common.touch_action import  import TouchAction

desires_caps = {}
desires_caps['platformName'] = 'Android'
desires_caps['platformVersion'] = '7'
desires_caps['deviceName'] = 'FA6930305423'
desires_caps['appPackage'] = 'com.netease.newsreader.activity'
desires_caps['appActivity'] = 'com.netease.nr.phone.main.MainActivity'
desires_caps['noReset'] = True

# 启动APP
driver = webdriver.Remote('http://localhost:4723/wd/hub',desires_caps)

#等待时间
sleep(5)

#点击底部栏首页
driver.find_element_by_id("com.netease.newsreader.activity:id/a2k").click()
sleep(2)

#点击普通帖
driver.tap([455,741],500)
#遍历文章的所有图片
pictures = driver.find_element_by_class_name("android.widget.Image")
for picture in pictures:
    print("picture[1]")

#点击图片放大查看
pictures[1].click()
#点击图片任意一处，图片退出全屏
driver.tap([450,680])

#返回首页
driver.find_element_by_id("com.netease.newsreader.activity:id/rw").click()

