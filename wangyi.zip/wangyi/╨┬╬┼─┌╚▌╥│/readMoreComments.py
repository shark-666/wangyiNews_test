from appium import webdriver
from time import sleep
from appium.webdriver.common.touch_action import  import TouchAction

desires_caps = {}
desires_caps['platformName'] = 'Android'
desires_caps['platformVersion'] = '7'
desires_caps['deviceName'] = 'FA6930305423'
desires_caps['appPackage'] = 'com.netease.newsreader.activity'
desires_caps['appActivity'] = 'com.netease.nr.phone.main.MainActivity'
desires_caps['noReset'] = True

# 启动APP
driver = webdriver.Remote('http://localhost:4723/wd/hub',desires_caps)

#等待时间
sleep(5)

#点击底部栏首页
driver.find_element_by_id("com.netease.newsreader.activity:id/a2k").click()
sleep(2)

#点击普通帖
driver.tap([455,741],500)
#点击更多评论按钮
driver.find_element_by_id("com.netease.newsreader.activity:id/ard").click()
sleep(2)
#滚动查看评论
driver.swipe(562,1490,521,331)
#给评论点赞
driver.find_element_by_id("com.netease.newsreader.activity:id/aqn").click()
#查看贴主个人详情
driver.find_element_by_id("com.netease.newsreader.activity:id/aql").click()

#返回文章内容
driver.find_element_by_id("com.netease.newsreader.activity:id/rw").click()

#返回首页
driver.find_element_by_id("com.netease.newsreader.activity:id/rw").click()

