from appium import webdriver
from time import sleep
from appium.webdriver.common.touch_action import  import TouchAction

desires_caps = {}
desires_caps['platformName'] = 'Android'
desires_caps['platformVersion'] = '7'
desires_caps['deviceName'] = 'FA6930305423'
desires_caps['appPackage'] = 'com.netease.newsreader.activity'
desires_caps['appActivity'] = 'com.netease.nr.phone.main.MainActivity'
desires_caps['noReset'] = True

# 启动APP
driver = webdriver.Remote('http://localhost:4723/wd/hub',desires_caps)

#等待时间
sleep(5)

#点击底部栏首页
driver.find_element_by_id("com.netease.newsreader.activity:id/a2k").click()
sleep(2)

#点击普通帖
driver.tap([455,741],500)
#向下滚动屏幕
driver.swipe(502,1719,527,268,100)
#再次滑动屏幕
driver.swipe(502,1719,527,268,100)
#点击喜欢按钮
driver.find_element_by_class_name("//android.view.View[contains[@text,"人喜欢"]]").click()

#返回首页
driver.find_element_by_id("com.netease.newsreader.activity:id/rw").click()

