from appium import webdriver
from time import sleep
from appium.webdriver.common.touch_action import  import TouchAction

desires_caps = {}
desires_caps['platformName'] = 'Android'
desires_caps['platformVersion'] = '7'
desires_caps['deviceName'] = 'FA6930305423'
desires_caps['appPackage'] = 'com.netease.newsreader.activity'
desires_caps['appActivity'] = 'com.netease.nr.phone.main.MainActivity'
desires_caps['noReset'] = True

# 启动APP
driver = webdriver.Remote('http://localhost:4723/wd/hub',desires_caps)

#等待时间
sleep(5)

#点击底部栏首页
driver.find_element_by_id("com.netease.newsreader.activity:id/a2k").click()
sleep(2)

#点击置顶帖
driver.find_element_by_xpath("//android.widget.TextView[contais(@text,"置顶")]").click()
sleep(3)
#滚动页面查看新闻
driver.swipe(419,1245,558,435)
sleep(1)
driver.swipe(182.970,251,872)
sleep(1)
#点击订阅按钮
driver.find_element_by_xpath("//android.view.View[contais(@text,"订阅")]").click()
#取消订阅
driver.find_element_by_xpath("//android.view.View[contais(@text,"已订阅")]").click()

#返回首页
driver.find_element_by_id("com.netease.newsreader.activity:id/rw").click()

